

// Your web app's Firebase configuration
var firebaseConfig = {
    apiKey: "AIzaSyCjVBbzCC-Fa8K72b_w_knuJ5F_plQ5WY0",
    authDomain: "citrakbs-c40f5.firebaseapp.com",
    databaseURL: "https://citrakbs-c40f5.firebaseio.com",
    projectId: "citrakbs-c40f5",
    storageBucket: "citrakbs-c40f5.appspot.com",
    messagingSenderId: "964072807195",
    appId: "1:964072807195:web:e115eaf67ddda3e56351be",
    measurementId: "G-4GW1R8M6W2"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
  const db=firebase.firestore();  
  
