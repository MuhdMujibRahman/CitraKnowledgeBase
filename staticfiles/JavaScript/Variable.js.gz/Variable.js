
newValue=localStorage.getItem("value");
newValue2=localStorage.getItem("value2");
newValue3=localStorage.getItem("Interest");
button=localStorage.getItem("button_log");